using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

namespace PFV.Grass
{
    public struct SubBufferData
    {
        public uint startOffset;
        public int size;
    }
    public class SharedBuffer<T> : IDisposable
    {
        public ComputeBuffer buffer { get; private set; }

        public int size { get; private set; }
        private Dictionary<int, SubBufferData> _subBufferData;
        public int stride { get; private set; }

        public SubBufferData this[int subBufferID]
        {
            get
            {
                if (_subBufferData.TryGetValue(subBufferID, out SubBufferData data))
                    return data;
                return default;
            }
        }


        public SharedBuffer(int stride)
        {
            this.stride = stride;
        }
        public SharedBuffer()
        {
            this.stride = Marshal.SizeOf<T>();
        }
        public void Allocate(ComputeBufferType type)
        {
            buffer = new ComputeBuffer(size, stride, type);
        }
        public int AddSubBuffer(int id, int size)
        {
            int offset = this.size;
            this.size += size;

            _subBufferData.Add(id, new SubBufferData() { size = size, startOffset = (uint)offset });
            return 0;
        }

        public bool SetData(int subBufferID, T[] data)
        {
            if (_subBufferData.TryGetValue(subBufferID, out SubBufferData subBufferData))
            {
                if (data.Length > subBufferData.size)
                {
                    Debug.LogError("Trying to set more data into subBuffer than it fits");
                    return false;
                }
                buffer.SetData(data, 0, (int)subBufferData.startOffset, data.Length);
                return true;
            }
            return false;
        }

        public void Dispose()
        {
            buffer?.Dispose();
            buffer = null;
        }
    }
}