using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using Random = UnityEngine.Random;
using Unity.Mathematics;
using UnityEngine.Profiling;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace PFV.Grass
{

    public class IndirectGrassRenderFeature : ScriptableRendererFeature
    {
        [SerializeField]
        private bool _doShadows;
        [SerializeField]
        private bool _doCulling;

        [SerializeField]
        private Settings _settings;

        [NonSerialized]
        private SharedData _sharedData;

        // Passes
        private CullingPass _cullingPass;
        private GrassRenderPass _grassPass;
        private GrassShadowCasterPass _shadowCasterPass;

        /// <inheritdoc/>
        public override void Create()
        {
            _sharedData?.Dispose();
            _sharedData = new SharedData(_settings);
            _grassPass = new GrassRenderPass(_sharedData);
            _cullingPass = new CullingPass(_sharedData);
            _shadowCasterPass = new GrassShadowCasterPass(_sharedData);
            _grassPass.renderPassEvent = _settings.renderPassEvt;
            _cullingPass.renderPassEvent = _settings.cullingPassEvt;
            // _shadowPass.renderPassEvent = _settings.shadowPassEvt;
        }
        protected override void Dispose(bool disposing)
        {
            _sharedData?.Dispose();
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (_doCulling)
            {
                renderer.EnqueuePass(_cullingPass);
            }

            renderer.EnqueuePass(_grassPass);

            if (_doShadows && renderer is UniversalRenderer universalRenderer)
            {
                universalRenderer.EnqueueShadowCasterPass(_shadowCasterPass);
            }
        }
        [System.Serializable]
        public class Settings
        {
            [SerializeField]
            private Mesh _mesh;
            public Mesh mesh => _mesh;
            [SerializeField]
            private Material _material;
            public Material material => _material;
            [SerializeField]
            private ComputeShader _grassCulling;
            public ComputeShader grassCulling => _grassCulling;
            [SerializeField]
            private ComputeShader _generateBlades;
            public ComputeShader generateBlades => _generateBlades;
            [SerializeField]
            private ComputeShader _interpolateBladeData;
            public ComputeShader interpolateBladeData => _interpolateBladeData;
            [SerializeField]
            private ComputeShader _collectVisibleTriangles;
            public ComputeShader collectVisibleTriangles => _collectVisibleTriangles;
            [SerializeField]
            private ComputeShader _cullingCompute;
            public ComputeShader cullingCompute => _cullingCompute;
            [SerializeField]
            private int _vertexSimulatedHeight = 1;
            public int vertexSimulatedHeight => _vertexSimulatedHeight;
            [SerializeField]
            private uint _maxTriangles = 100000;
            public uint maxTriangles => _maxTriangles;
            [SerializeField]
            private uint _maxBlades = 1000000;
            public uint maxBlades => _maxBlades;
            [SerializeField]
            private int _seed = 0;
            public int seed => _seed;
            [SerializeField]
            private int _commandCount = 1;
            public int commandCount => _commandCount;
            [SerializeField]
            private int _areaSize = 10;
            public int areaSize => _areaSize;
            [SerializeField]
            private Vector3 _scale = Vector3.one;
            public Vector3 scale => _scale;
            [SerializeField]
            private RenderPassEvent _renderPassEvt = RenderPassEvent.AfterRenderingOpaques;
            public RenderPassEvent renderPassEvt => _renderPassEvt;
            [SerializeField]
            private RenderPassEvent _cullingPassEvt = RenderPassEvent.BeforeRendering;
            public RenderPassEvent cullingPassEvt => _cullingPassEvt;

            public bool IsValid()
            {
                return _mesh && material;
            }

        }
        struct AABBData
        {
            public Vector3 boundsCenter;
            public Vector3 boundsExtents;
        };
        class SharedData : IDisposable
        {
            private GrassRendererManager _mgr;
            public GrassRendererManager mgr => _mgr;
            private Settings _settings;
            public Settings settings => _settings;
            private Buffers _buffers;
            public Buffers buffers => _buffers;

            public SharedData(Settings settings)
            {
                _mgr = GrassRendererManager.Instance;
                _settings = settings;
                _buffers = new Buffers(this);
            }

            public void SetInitialVertex()
            {
            }


            public void Dispose()
            {
                _buffers?.Dispose();
            }
        }
        class Buffers : IDisposable
        {

            public enum GlobalArgs
            {
                DrawArgs,
                ShadowDrawArgs,
                GenerateBladesArgs,
                InterpolateBladesArgs,
            }

            private SharedBuffer<uint> _globalArgsBuffer;
            public SharedBuffer<uint> globalArgsBuffer => _globalArgsBuffer;

            private ComputeBuffer _trianglesBuffer;
            public ComputeBuffer trianglesBuffer => _trianglesBuffer;

            private ComputeBuffer _vertexBuffer;
            public ComputeBuffer vertexBuffer => _vertexBuffer;

            private ComputeBuffer _visibleTrianglesAppendBuffer;
            public ComputeBuffer visibleTrianglesAppendBuffer => _visibleTrianglesAppendBuffer;


            private ComputeBuffer _visibleBladesAppendBuffer;
            public ComputeBuffer visibleBladesAppendBuffer => _visibleBladesAppendBuffer;

            private ComputeBuffer _isVisiblePerVertex;
            public ComputeBuffer isVisiblePerVertex => _isVisiblePerVertex;

            public int vertexAmount { get; private set; }
            public int triangleAmount { get; private set; }

            public Buffers(SharedData sharedData)
            {
                _globalArgsBuffer = new SharedBuffer<uint>(sizeof(uint) * 5);
                _globalArgsBuffer.AddSubBuffer((int)GlobalArgs.DrawArgs, 5);
                _globalArgsBuffer.AddSubBuffer((int)GlobalArgs.ShadowDrawArgs, 5);
                _globalArgsBuffer.AddSubBuffer((int)GlobalArgs.InterpolateBladesArgs, 3);
                _globalArgsBuffer.Allocate(ComputeBufferType.IndirectArguments);
                _globalArgsBuffer.SetData((int)GlobalArgs.DrawArgs, new uint[5] {
                    (uint)sharedData.settings.mesh.GetIndexCount(0),
                    0, // filled by compute
                    (uint)sharedData.settings.mesh.GetIndexStart(0),
                    (uint)sharedData.settings.mesh.GetBaseVertex(0) ,
                    0
                });
                _globalArgsBuffer.SetData((int)GlobalArgs.ShadowDrawArgs, new uint[5] {
                    (uint)sharedData.settings.mesh.GetIndexCount(0),
                    0, // filled by compute
                    (uint)sharedData.settings.mesh.GetIndexStart(0),
                    (uint)sharedData.settings.mesh.GetBaseVertex(0) ,
                    0
                });
                // stride is wrong, will it matter...?
                _globalArgsBuffer.SetData((int)GlobalArgs.GenerateBladesArgs, new uint[3] {
                    0, // thread groups X (filled by compute)
                    1, // thread groups Y
                    1  // thread groups Z
                });
                _globalArgsBuffer.SetData((int)GlobalArgs.InterpolateBladesArgs, new uint[3] {
                    0, // thread groups X (filled by compute)
                    1, // thread groups Y
                    1  // thread groups Z
                });

                _isVisiblePerVertex = new ComputeBuffer((int)(sharedData.buffers.vertexAmount), Marshal.SizeOf<VertexCullResult>(), ComputeBufferType.Structured);

                _visibleBladesAppendBuffer = new ComputeBuffer((int)(sharedData.settings.maxBlades), Marshal.SizeOf<GrassBladeInstanceData>(), ComputeBufferType.Append);
                _visibleTrianglesAppendBuffer = new ComputeBuffer((int)(sharedData.settings.maxTriangles), sizeof(uint), ComputeBufferType.Append);
                List<GrassVertex> vertices = new List<GrassVertex>();
                List<GrassTriangle> triangles = new List<GrassTriangle>();
                sharedData.mgr.GetAllVertexAndTriangles(ref vertices, ref triangles);
                _vertexBuffer = new ComputeBuffer(vertices.Count, Marshal.SizeOf<GrassVertex>(), ComputeBufferType.Structured);
                _trianglesBuffer = new ComputeBuffer(triangles.Count, Marshal.SizeOf<GrassTriangle>(), ComputeBufferType.Structured);
                vertexAmount = vertices.Count;
                triangleAmount = triangles.Count;
                _vertexBuffer.SetData(vertices);
                _trianglesBuffer.SetData(triangles);
            }

            public void Dispose()
            {
                _globalArgsBuffer?.Dispose();
                _globalArgsBuffer = null;
                _visibleTrianglesAppendBuffer?.Dispose();
                _visibleTrianglesAppendBuffer = null;
                _visibleBladesAppendBuffer?.Dispose();
                _visibleBladesAppendBuffer = null;

            }
        }
        static class ShaderPropertyIDs
        {

            public static int bladesDispatchCountOffsetID = Shader.PropertyToID("_BladesDispatchCount_ArgsBufferOffset");
            public static int visibleTriangleIndexesID = Shader.PropertyToID("_VisibleTriangleIndexes");
            public static int isVisiblePerVertexID = Shader.PropertyToID("_IsVisiblePerVertex");
            public static int cameraFrustrumID => Shader.PropertyToID("_CameraFrustrumMatrix");
            public static int objectToWorldID => Shader.PropertyToID("_ObjectToWorld");
            public static int verticesID => Shader.PropertyToID("_Vertices");
            public static int trianglesID => Shader.PropertyToID("_Triangles");
            public static int trianglePerBlade => Shader.PropertyToID("_TrianglePerBlade");
            public static int bladeInstancesID => Shader.PropertyToID("_BladeInstances");

            public static int totalVerticesID => Shader.PropertyToID("_TotalVertices");
            public static int totalTrianglesID => Shader.PropertyToID("_TotalTriangles");
            public static int vertexSimulatedHeightID => Shader.PropertyToID("_VertexSimulatedHeight");
        }
        static class CSKernelNames
        {
            public const string grassVertexCulling = "CS_GrassVertexCulling";
            public const string collectVisibleTriangles = "CS_CollectVisibleTriangles";
            public const string generateBlades = "CS_GenerateBladesAmount";
            public const string interpolateBladeData = "CS_InterpolateBladeData";
        }
        class CullingPass : ScriptableRenderPass
        {
            private SharedData _data;

            private int _grassCullingKernelID;
            private int _collectVisibleTrianglesKernelID;
            private int _generateBladesKernelID;
            private int _interpolateBladeDataKernelID;

            private ComputeShader _grassCullingCS;
            private ComputeShader _generateBladesCS;
            private ComputeShader _interpolateBladeDataCS;
            private ComputeShader _collectVisibleTrianglesCS;

            private bool _isSetup;

            private static Vector3Int cullingThreads = new Vector3Int(128, 1, 1);

            private const int MAX_CS_THREAD_GROUPS = 65535;

            public CullingPass(SharedData sharedData)
            {
                _data = sharedData;
                Setup();
            }

            private bool Setup()
            {
                _isSetup = false;
                if (!_data.settings.grassCulling
                 || !_data.settings.generateBlades
                 || !_data.settings.interpolateBladeData
                 || !_data.settings.collectVisibleTriangles)
                    return false;

                _grassCullingCS = _data.settings.grassCulling;
                _generateBladesCS = _data.settings.generateBlades;
                _interpolateBladeDataCS = _data.settings.interpolateBladeData;
                _collectVisibleTrianglesCS = _data.settings.collectVisibleTriangles;

                _grassCullingKernelID = _grassCullingCS.FindKernel(CSKernelNames.grassVertexCulling);
                _generateBladesKernelID = _generateBladesCS.FindKernel(CSKernelNames.generateBlades);
                _interpolateBladeDataKernelID = _interpolateBladeDataCS.FindKernel(CSKernelNames.interpolateBladeData);
                _collectVisibleTrianglesKernelID = _collectVisibleTrianglesCS.FindKernel(CSKernelNames.collectVisibleTriangles);


                return _isSetup = true;
            }


            public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
            {
                if (!_isSetup && !Setup())
                    return;

                Camera camera = renderingData.cameraData.camera;
                var cameraFrustumPlanes = math.mul(camera.projectionMatrix, camera.worldToCameraMatrix);

                CommandBuffer cmd = CommandBufferPool.Get();
                cmd.Clear();

                cmd.SetBufferCounterValue(_data.buffers.isVisiblePerVertex, 0);
                cmd.SetComputeBufferParam(_grassCullingCS, _grassCullingKernelID, ShaderPropertyIDs.isVisiblePerVertexID, _data.buffers.isVisiblePerVertex);
                cmd.SetComputeBufferParam(_grassCullingCS, _grassCullingKernelID, ShaderPropertyIDs.verticesID, _data.buffers.vertexBuffer);
                cmd.SetComputeMatrixParam(_grassCullingCS, ShaderPropertyIDs.cameraFrustrumID, cameraFrustumPlanes);
                cmd.SetComputeIntParam(_grassCullingCS, ShaderPropertyIDs.totalVerticesID, (int)_data.buffers.vertexAmount);
                cmd.DispatchCompute(_grassCullingCS, _grassCullingKernelID, Mathf.CeilToInt(_data.buffers.vertexAmount / (float)cullingThreads.x), cullingThreads.y, cullingThreads.z);

                cmd.SetComputeBufferParam(_collectVisibleTrianglesCS, _collectVisibleTrianglesKernelID, ShaderPropertyIDs.isVisiblePerVertexID, _data.buffers.isVisiblePerVertex);
                cmd.SetComputeBufferParam(_collectVisibleTrianglesCS, _collectVisibleTrianglesKernelID, ShaderPropertyIDs.trianglesID, _data.buffers.trianglesBuffer);
                cmd.SetComputeBufferParam(_collectVisibleTrianglesCS, _collectVisibleTrianglesKernelID, ShaderPropertyIDs.visibleTriangleIndexesID, _data.buffers.visibleTrianglesAppendBuffer);
                cmd.SetComputeIntParam(_collectVisibleTrianglesCS, ShaderPropertyIDs.totalTrianglesID, _data.buffers.triangleAmount);
                cmd.SetComputeIntParam(_collectVisibleTrianglesCS, ShaderPropertyIDs.bladesDispatchCountOffsetID, _data.buffers.globalArgsBuffer[(int)Buffers.GlobalArgs.GenerateBladesArgs].startOffset);
                cmd.DispatchCompute(_collectVisibleTrianglesCS, _collectVisibleTrianglesKernelID, Mathf.CeilToInt(_data.buffers.triangleAmount / (float)cullingThreads.x), cullingThreads.y, cullingThreads.z);

                cmd.CopyCounterValue(_data.buffers.visibleTrianglesAppendBuffer, _data.buffers.globalArgsBuffer.buffer, _data.buffers.globalArgsBuffer[(int)Buffers.GlobalArgs.GenerateBladesArgs].startOffset);
                cmd.SetComputeIntParam(_collectVisibleTrianglesCS, ShaderPropertyIDs.bladesDispatchCountOffsetID, _data.buffers.globalArgsBuffer[(int)Buffers.GlobalArgs.GenerateBladesArgs].startOffset);
// cmd.global
cmd.

                cmd.DispatchCompute(_generateBladesCS, _generateBladesKernelID, _data.buffers.globalArgsBuffer.buffer, _data.buffers.globalArgsBuffer[(int)Buffers.GlobalArgs.InterpolateBladesArgs].startOffset);
                context.ExecuteCommandBuffer(cmd);
                CommandBufferPool.Release(cmd);

            }

        }
        class GrassShadowCasterPass : ExtraShadowCasterPass
        {
            private SharedData _sharedData;

            MaterialPropertyBlock _block;
            public GrassShadowCasterPass(SharedData sharedData)
            {
                _sharedData = sharedData;
                _block = new MaterialPropertyBlock();
                if (sharedData.settings.IsValid())
                {
                    _block.SetMatrix(ShaderPropertyIDs.objectToWorldID, Matrix4x4.TRS(Vector3.zero, Quaternion.identity, Vector3.one));
                    // _block.SetBuffer(ShaderVariableIDs.positionsBufferID, sharedData.buffers.positions);
                }
            }

            public override void ExecuteDuringShadows(CommandBuffer cmd, ref ScriptableRenderContext context, ref ShadowSliceData shadowSliceData, ref ShadowDrawingSettings settings)
            {
                if (!_sharedData.settings.IsValid())
                    return;

                cmd.DrawMeshInstancedIndirect(_sharedData.settings.mesh, 0, _sharedData.settings.material, _sharedData.settings.material.FindPass("ShadowCaster"), _sharedData.buffers.shadowIndirectArgsBuffer, 0, _block);
            }

        }

        class GrassRenderPass : ScriptableRenderPass
        {
            private MaterialPropertyBlock _block;
            private SharedData _sharedData;

            public GrassRenderPass(SharedData sharedData)
            {
                _sharedData = sharedData;
                base.profilingSampler = new ProfilingSampler("Grass Forward Pass");
                _block = new MaterialPropertyBlock();
                _block.SetMatrix(ShaderPropertyIDs.objectToWorldID, Matrix4x4.TRS(Vector3.zero, Quaternion.identity, Vector3.one));
                // _block.SetBuffer(ShaderVariableIDs.positionsBufferID, sharedData.buffers.positions);
                _block.SetBuffer(ShaderPropertyIDs.visibleInstancesBufferID, sharedData.buffers.visibleIndicesAppendBuffer);
            }
            public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
            {
                if (!_sharedData.settings.IsValid())
                    return;

                CommandBuffer cmd = CommandBufferPool.Get();
                cmd.Clear();
                cmd.DrawMeshInstancedIndirect(_sharedData.settings.mesh, 0, _sharedData.settings.material, 0, _sharedData.buffers.indirectArgsBuffer, 0, _block);
                context.ExecuteCommandBuffer(cmd);
                CommandBufferPool.Release(cmd);
            }


        }
    }








}