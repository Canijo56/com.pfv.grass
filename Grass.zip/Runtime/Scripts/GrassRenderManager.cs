using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace PFV.Grass
{
    [System.Serializable]
    public struct GrassBladeInstanceData
    {
        public Vector3 positionWS;
        public uint batchIndex;
        public Vector3 normalWS;
        public uint triangleIndex;
    }
    [System.Serializable]
    public struct GrassPatch
    {
        public GrassVertex[] vertices;
        public GrassTriangle[] triangles;
    }
    [System.Serializable]
    public struct GrassVertex
    {
        public Vector3 position;
        public Vector3 normal;
        public float density;
    }
    [System.Serializable]
    public struct GrassTriangle
    {
        public uint vertexA;
        public uint vertexB;
        public uint vertexC;
    }
    public struct IndirectBatchData
    {
        public int instanceCount;
    }
    public struct VertexCullResult
    {
        public float visible;
    }
    [System.Serializable]
    public struct MaterialData
    {
        public Color color;
    }
    [ExecuteInEditMode]
    public class GrassRendererManager : Singleton<GrassRendererManager>
    {
        [SerializeField]
        List<GrassProvider> _providers = new List<GrassProvider>();

        static GrassRendererManager()
        {
            autoInstantiate = true;
        }

        public void GetAllVertexAndTriangles(ref List<GrassVertex> vertices, ref List<GrassTriangle> triangles)
        {
            for (int i = 0; i < _providers.Count; i++)
            {
                if (_providers[i])
                {
                    _providers[i].GetData(ref vertices, ref triangles);
                }
            }
        }

        public static void RegisterProvider(GrassProvider grassProvider)
        {
            GrassRendererManager mgr = Instance;
            if (!mgr)
                return;
#if UNITY_EDITOR
            if (!Application.isPlaying)
                using (UndoUtils.RecordScope(mgr))
#endif
                {
                    if (!mgr._providers.Contains(grassProvider))
                        mgr._providers.Add(grassProvider);
                }
        }
        public static void UnregisterProvider(GrassProvider grassProvider)
        {
            GrassRendererManager mgr = Instance;
            if (!mgr)
                return;
#if UNITY_EDITOR
            if (!Application.isPlaying)
                using (UndoUtils.RecordScope(mgr))
#endif
                {
                    if (mgr._providers.Contains(grassProvider))
                        mgr._providers.Remove(grassProvider);
                }
        }

        protected override void OnSingletonAwake()
        {
            base.OnSingletonAwake();
        }

        protected override void OnSingletonDestroy()
        {
            base.OnSingletonDestroy();
        }

        protected override void OnSingletonDisable()
        {
            base.OnSingletonDisable();
        }

        protected override void OnSingletonEnable()
        {
            base.OnSingletonEnable();
        }
    }
}