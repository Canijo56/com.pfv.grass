using System;
using UnityEngine;

namespace PFV.Grass
{
    public class Singleton : MonoBehaviour
    {
        internal static event Action ReleaseInstances;
        // TODO: not really necesary with OnDomainLoad /Unload callbacks?

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void InitializeOnLoad()
        {
            ReleaseInstances?.Invoke();
        }
    }
    public class Singleton<T> : Singleton
        where T : Singleton<T>
    {
        private static bool hasInitialized = false;
        public static bool autoInstantiate = false;
        public static bool dontDestroyOnLoad = false;
        public static bool playmodeCallbacks = false;
        public static bool beforeAssemblyReloadCallback = false;
        public static bool afterAssemblyReloadCallback = false;
        public static bool onDomainUnloadCallback = false;

        private static T _instance;

        public static T Instance
        {
            get
            {
                if (_instance)
                    return _instance;
                _instance = GameObject.FindObjectOfType<T>();
                if (!_instance)
                {
                    if (autoInstantiate)
                    {
                        _instance = new GameObject(typeof(T).Name).AddComponent<T>();
#if UNITY_EDITOR
                        if (!Application.isPlaying)
                        {
                            UnityEditor.Undo.RegisterCreatedObjectUndo(_instance.gameObject, $"Auto instantiated {typeof(T).Name} Singleton");
                            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(_instance.gameObject.scene);
                        }
#endif
                    }
                }
                else
                {
                    _instance.Awake();
                }
                return _instance;

            }
        }

        static Singleton()
        {
            Singleton.ReleaseInstances -= ReleaseInstance;
            Singleton.ReleaseInstances += ReleaseInstance;
        }

        public static bool HasInstance()
        {
            return _instance != null;
        }


        private void Awake()
        {
            if (hasInitialized)
                return;

            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }

            hasInitialized = true;
            _instance = this as T;

#if UNITY_EDITOR
            if (Application.isPlaying)
#endif
                if (dontDestroyOnLoad)
                    DontDestroyOnLoad(gameObject);

#if UNITY_EDITOR
            if (playmodeCallbacks)
            {
                UnityEditor.EditorApplication.playModeStateChanged -= OnPlaymodeChange;
                UnityEditor.EditorApplication.playModeStateChanged += OnPlaymodeChange;
            }
#endif

            OnSingletonAwake();
        }

        public static void ReleaseInstance()
        {
            hasInitialized = false;
            _instance = null;
        }

        protected virtual void OnEnable()
        {

            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            if (!hasInitialized)
            {
                Awake();
            }
            _instance = this as T;
#if UNITY_EDITOR
            if (beforeAssemblyReloadCallback)
            {
                UnityEditor.AssemblyReloadEvents.beforeAssemblyReload -= OnBeforeAssemblyReload;
                UnityEditor.AssemblyReloadEvents.beforeAssemblyReload += OnBeforeAssemblyReload;
            }
            if (afterAssemblyReloadCallback)
            {
                UnityEditor.AssemblyReloadEvents.afterAssemblyReload -= OnAfterAssemblyReload;
                UnityEditor.AssemblyReloadEvents.afterAssemblyReload += OnAfterAssemblyReload;
            }
#endif
            AppDomain.CurrentDomain.DomainUnload -= OnDomainUnload;
            AppDomain.CurrentDomain.DomainUnload += OnDomainUnload;

            OnSingletonEnable();
        }

        protected virtual void OnDisable()
        {
            if (!hasInitialized)
                return;

            OnSingletonDisable();

            _instance = null;
        }

        private void OnDestroy()
        {
            if (!hasInitialized)
                return;
#if UNITY_EDITOR
            if (playmodeCallbacks)
            {
                UnityEditor.EditorApplication.playModeStateChanged -= OnPlaymodeChange;
            }
            if (beforeAssemblyReloadCallback)
            {
                UnityEditor.AssemblyReloadEvents.beforeAssemblyReload -= OnBeforeAssemblyReload;
            }
            if (afterAssemblyReloadCallback)
            {
                UnityEditor.AssemblyReloadEvents.afterAssemblyReload -= OnAfterAssemblyReload;
            }
#endif
            OnSingletonDestroy();
            AppDomain.CurrentDomain.DomainUnload -= OnDomainUnload;
            hasInitialized = false;
            _instance = null;
        }

        private void OnDomainUnload(object sender, EventArgs e)
        {
            // Log($"On Assembly Unload {GetType().Name}");

            AppDomain.CurrentDomain.DomainUnload -= OnDomainUnload;
            hasInitialized = false;
            _instance = null;
        }


#if UNITY_EDITOR
        protected virtual void OnAfterAssemblyReload()
        {
        }

        protected virtual void OnBeforeAssemblyReload()
        {
        }

        protected virtual void OnPlaymodeChange(UnityEditor.PlayModeStateChange state)
        {
            // switch(state)
            // {
            // case UnityEditor.PlayModeStateChange.EnteredEditMode: break;
            // case UnityEditor.PlayModeStateChange.ExitingEditMode: break;
            // case UnityEditor.PlayModeStateChange.EnteredPlayMode: break;
            // case UnityEditor.PlayModeStateChange.ExitingPlayMode: break;
            // }
        }
#endif

        protected virtual void OnSingletonAwake() { }
        protected virtual void OnSingletonDestroy() { }
        protected virtual void OnSingletonEnable() { }
        protected virtual void OnSingletonDisable() { }
    }
}