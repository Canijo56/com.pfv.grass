using UnityEngine;

namespace PFV.Grass
{

    public class DummyAsset : ScriptableObject
    {

    }
}